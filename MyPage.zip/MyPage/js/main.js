// 主要的JavaScript功能
document.addEventListener('DOMContentLoaded', () => {
    console.log('Main script loaded');
}); 